#include <string>
int main(int argc, char* argv[])
{
    unsigned int x=0;
    return x;
}
